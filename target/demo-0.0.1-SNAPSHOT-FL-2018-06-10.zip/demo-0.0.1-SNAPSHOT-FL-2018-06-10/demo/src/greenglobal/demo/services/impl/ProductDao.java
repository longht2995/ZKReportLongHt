package greenglobal.demo.services.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import greenglobal.demo.entity.Product;

@Repository
public class ProductDao {
	@PersistenceContext
	private EntityManager em;
	@Transactional
	public List<Product> listAll(){
		return em.createQuery("SELECT p FROM Product p").getResultList();
	}
}
